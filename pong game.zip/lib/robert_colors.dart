import 'dart:ui';

class RobertColors {
  static Color get background => Color(0xff1E1E20);
  static Color get surface => Color(0xff29292D);
  static Color get primary => Color(0xffC34C4C);
}
